A Pen created at CodePen.io. You can find this one at http://codepen.io/osublake/pen/NdEONL.

 Really smooth on mobile / touch enabled devices.